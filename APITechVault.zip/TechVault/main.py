from urllib import request
from fastapi import FastAPI
from bs4 import BeautifulSoup
import requests 

app = FastAPI()


@app.get("/")
async def home():
    return {"message": "Welcome to TechVault API"}

def fetch_mdn_docs(topic):
    """Fetches MDN documentation for a given topic."""
    base_url = f"https://developer.mozilla.org/en-US/docs/Web/{topic}"
    headers = {"User-Agent": "Mozilla/5.0"}
    
    response = requests.get(base_url, headers=headers)
    if response.status_code != 200:
        return {"error": f"Could not fetch data. Status code: {response.status_code}"}
    
    soup = BeautifulSoup(response.text, "html.parser")
    title = soup.find("h1").text.strip() if soup.find("h1") else "No title found"
    content_div = soup.find("div", class_="main-page-content")
    content = content_div.get_text("\n").strip() if content_div else "No content found"
    
    return {
        "title": title,
        "url": base_url,
        "content": content[:500]  
    }


@app.get("/mdn/{topic}")
def get_mdn_documentation(topic: str):
  return fetch_mdn_docs(topic)